[Setup]
AppName=OpenSC smartcard framework
AppVerName=OpenSC smartcard framework 0.20.0
AppPublisher=@OPENSC_VS_FF_LEGAL_COMPANY_NAME@
AppPublisherURL=https://github.com/OpenSC
AppSupportURL=@PRODUCT_BUGREPORT@
AppUpdatesURL=https://github.com/OpenSC/OpenSC/releases
DefaultDirName={pf}\OpenSC Project\OpenSC
OutputBaseFilename=OpenSC-0.20.0
Compression=lzma/normal
SolidCompression=true
MinVersion=0,5.0.2195
VersionInfoCompany=OpenSC Project
AppCopyright=LGPL
PrivilegesRequired=poweruser
DisableDirPage=false
DisableProgramGroupPage=false
ShowLanguageDialog=auto
AppID={{BDD73EB0-0485-4B79-93EC-CF2EAEFF3BAB}
UsePreviousAppDir=true
AppendDefaultDirName=false
AppVersion=0.20.0
VersionInfoVersion=0.20.0
VersionInfoDescription=OpenSC tools and libraries
VersionInfoTextVersion=0.20.0
DisableReadyPage=true
InternalCompressLevel=max
VersionInfoCopyright=OpenSC Project
DisableStartupPrompt=true
AlwaysShowComponentsList=false
ShowComponentSizes=false
FlatComponentsList=false
WizardImageBackColor=clWhite
DisableFinishedPage=false
VersionInfoProductName=OpenSC
VersionInfoProductVersion=0.20.0
AllowRootDirectory=true
UninstallDisplayName=OpenSC
DefaultGroupName=OpenSC

[Tasks]

[Files]
Source: opensc\share\opensc\*.profile; DestDir: {app}\profiles
Source: opensc\bin\*.dll; DestDir: {sys}; Flags: overwritereadonly replacesameversion ignoreversion uninsnosharedfileprompt restartreplace
Source: opensc\bin\*.exe; DestDir: {app}; Flags: overwritereadonly replacesameversion ignoreversion
;Source: engine_pkcs11\*.dll; DestDir: {sys}; Components: OpenSSL_engine; Flags: overwritereadonly replacesameversion ignoreversion
Source: opensc\etc\opensc.conf; DestDir: {app};
;Source: www.opensc-project.org.url; DestDir: {app}
[Icons]
;Name: {group}\OpenSC Project website; Filename: {app}\www.opensc-project.org.url; Comment: Go to OpenSC Project website; Components:

[Registry]
Root: HKLM; Subkey: Software\OpenSC Project\OpenSC; ValueType: string; ValueName: ConfigFile; ValueData: {app}\opensc.conf; Flags: uninsdeletekey; Components:
Root: HKLM; Subkey: Software\OpenSC Project\OpenSC; ValueType: string; ValueName: ProfileDir; ValueData: {app}\profiles; Flags: uninsdeletekey; Components:
;[Components]
;Name: OpenSC; Description: OpenSC core library; Flags: fixed; Types: custom compact full
;Name: OpenSSL_engine; Description: OpenSSL engine for using PKCS11 modules; Types: custom full
